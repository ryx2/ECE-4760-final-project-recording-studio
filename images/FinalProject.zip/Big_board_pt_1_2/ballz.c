/*
 * File:        TFT_test_BRL4.c
 * Author:      Bruce Land
 * Adapted from:
 *              main.c by
 * Author:      Syed Tahmid Mahbub
 * Target PIC:  PIC32MX250F128B
 */

////////////////////////////////////
// clock AND protoThreads configure!
// You MUST check this file!
#include "config.h"
// threading library
#include "pt_cornell_1_2.h"

////////////////////////////////////
// graphics libraries
#include "tft_master.h"
#include "tft_gfx.h"
// need for rand function
#include <stdlib.h>
////////////////////////////////////
#include "bubble.h" // our sounds fx
#include "punch.h" // our sounds fx
#include "reversed mario.h" // our sounds fx

/* Demo code for interfacing TFT (ILI9340 controller) to PIC32
 * The library has been modified from a similar Adafruit library
 */
// Adafruit data:
/***************************************************
  This is an example sketch for the Adafruit 2.2" SPI display.
  This library works with the Adafruit 2.2" TFT Breakout w/SD card
  ----> http://www.adafruit.com/products/1480

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution
 ****************************************************/

// string buffer
char buffer[60];
// old string buffer
char oldBuffer[60];

// === thread structures ============================================
// thread control structs
// note that UART input and output are threads
static struct pt pt_timer, pt_color, pt_anim, pt_sound, pt_insert, pt_paddle,pt_draw, pt_ballz ;

// system 1 second interval tick
int sys_time_seconds,i,j, oldestBall, begin_time ;
int gameOngoing=1;
int bumperLocation = 120, oldBumperLocation = 120; // bumper starts at top of screen
int currentBallz = 0;
unsigned int adc;
static float adcVoltage;
int score = 0;
int frameRate= 0, oldFrameRate=0;


#define bumperLength 20
#define bumperHorDist 20
#define ballRadius 2
#define ballCount 420
#define drag 0.9999999

#define scoreUp 1
#define scoreDown 2
#define endGame 3

#define gameDuration 60

// define setup parameters for OpenADC10
// ADC_CLK_AUTO -- Internal counter ends sampling and
//starts conversion (Auto convert)
// ADC_AUTO_SAMPLING_ON -- Sampling begins immediately after last
//conversion completes; SAMP bit is automatically set
// ADC_AUTO_SAMPLING_OFF -- Sampling begins with AcquireADC10();
// Turn module on|ouput in integer|trigger mode auto|enable autosample
#define PARAM1 ADC_FORMAT_INTG16 | ADC_CLK_AUTO | ADC_AUTO_SAMPLING_OFF
// ADC ref external | disable offset test | disable scan mode |
// do 1 sample | use single buf | alternate mode off
#define PARAM2 ADC_VREF_AVDD_AVSS | ADC_OFFSET_CAL_DISABLE | ADC_SCAN_OFF | ADC_SAMPLES_PER_INT_1 | ADC_ALT_BUF_OFF | ADC_ALT_INPUT_OFF
// use peripherial bus clock | set sample time | set ADC clock divider
// ADC_CONV_CLK_Tcy2 means divide CLK_PB by 2 (max speed)
// ADC_SAMPLE_TIME_5 seems to work with a source resistance < 1kohm
#define PARAM3 ADC_CONV_CLK_PB | ADC_SAMPLE_TIME_5 | ADC_CONV_CLK_Tcy2
// set AN11 and as analog inputs
#define PARAM4 ENABLE_AN11_ANA // pin 24
// do not assign channels to scan
#define PARAM5 SKIP_SCAN_ALL
// use ground as neg ref for A | use AN11 for input A

// === the fixed point macros ========================================
typedef signed int fix16 ;
#define multfix16(a,b) ((fix16)(((( signed long long)(a))*(( signed long long)(b)))>>16)) //multiply two fixed 16:16
#define float2fix16(a) ((fix16)((a)*65536.0)) // 2^16
#define fix2float16(a) ((float)(a)/65536.0)
#define fix2int16(a)    ((int)((a)>>16))
#define int2fix16(a)    ((fix16)((a)<<16))
#define divfix16(a,b) ((fix16)((((signed long long)(a)<<16)/(b)))) 
#define sqrtfix16(a) (float2fix16(sqrt(fix2float16(a)))) 
#define absfix16(a) abs(a)

//hw question 1
//0 is x location, 1 is y location, 2 is x velocity,
// 3 is y velocity, 4 is the hit counter,5 is valid bit, 6 is age
// 
// if valid bit is 1, ball is valid, 0 is invalid. 
static fix16 ballz[ballCount][7]; 

static fix16 oldBallz[ballCount][3]; // last time drawn x and y, and valid bits: needs to be initialized 

static fix16 rijx; //this is the radius
static fix16 rijy; //this is the radius
static fix16 vijx; // this is the velocity difference vector
static fix16 vijy; // this is the velocity difference vector
static fix16 dvx; // this is the velocity change vector
static fix16 dvy; // this is the velocity change vector
fix16 oldestAge;
fix16 mag;

// say ball i and ball j are colliding:


// === Timer Thread =================================================
// update a 1 second tick counter
static PT_THREAD (protothread_timer(struct pt *pt))
{
  PT_BEGIN(pt);
  tft_setTextSize(1);
  
  while(1) {
        // yield time 1 second
    frameRate = 0;
    PT_YIELD_TIME_msec(1000) ;
    sys_time_seconds++;
    if (sys_time_seconds>=60){
      gameOngoing=0;
    }
    oldFrameRate=frameRate;
    if (gameOngoing)
    {
      tft_setCursor(100, 2);
      tft_setTextColor(ILI9340_BLACK); 
      tft_writeString(oldBuffer);
      tft_setTextColor(ILI9340_YELLOW); 
      tft_setCursor(100, 2);
      sprintf(buffer,"Time=%i, fr=%d, balls=%i, score=%i", sys_time_seconds, oldFrameRate, currentBallz, score);
      tft_writeString(buffer);
      memcpy(oldBuffer, buffer, strlen(buffer)+1);
    }
        // NEVER exit while
  } // END WHILE(1)
  PT_END(pt);
} // timer thread

// === Animation Thread =============================================
// update a 1 second tick counter

// a couple optimization ideas: keep track of balls, if the the ball doesn't move since the prev frame, dont redraw
// keep an array 320x240 of all the lit pixels locations, manually draw each pixel.
// static PT_THREAD (protothread_anim(struct pt *pt))
// {
//   PT_BEGIN(pt);

static PT_THREAD (protothread_insert(struct pt *pt))
{
  PT_BEGIN(pt);
  while(1){
    oldestAge = 0;
    for (i = 0; i < ballCount; ++i){
      if (currentBallz == ballCount){
        if (ballz[i][5]){
          if (ballz[i][6] > oldestAge){
            oldestBall = i; 
            oldestAge = ballz[i][6]; 
          } 
        }
      } else { // current number of balls < ballcount, find the next ball and generate
        if (!ballz[i][5]){
          oldestBall = i;
          currentBallz++;
          break;
        }
      }
    }
    // now we generate a ball at oldestBall
    ballz[oldestBall][5]=float2fix16(1);
    ballz[oldestBall][0]=float2fix16(300);
    ballz[oldestBall][1]=float2fix16(120);
    ballz[oldestBall][6]=int2fix16(0); //set age to 0
    ballz[oldestBall][2]=(((rand() & 0xffff)<<1) - int2fix16(1))-int2fix16(2); // random velocity from -1 to -3
    ballz[oldestBall][3]=multfix16((((rand() & 0xffff)<<1) - int2fix16(1)),int2fix16(3)); // random velocity from -1.5 to 1.5
    
    // ballz[oldestBall][2]=multfix16((((rand() & 0xffff)<<1) - int2fix16(1)),float2fix16(10)); // random velocity from -3.5 to 3.5
    // ballz[oldestBall][3]=multfix16((((rand() & 0xffff)<<1) - int2fix16(1)),float2fix16(6)); // random velocity from -3.5 to 3.5
    // ballz[oldestBall][2]=int2fix16(0); //fixed vel for debug
    // ballz[oldestBall][3]=int2fix16(-3);
    PT_YIELD_TIME_msec(67);
  }
  PT_END(pt);
}

static PT_THREAD (protothread_draw(struct pt *pt))
{
  PT_BEGIN(pt);
  while(1){
    begin_time = PT_GET_TIME();
    if(gameOngoing){
      for (i = 0; i < ballCount; ++i){
        // tft_setCursor(20,80+i*10);
        // tft_fillRoundRect(20,80, 200, 10, 1, ILI9340_BLACK);// x,y,w,h,radius,color
        // sprintf(buffer,"xloc=%i,yloc=%i,xspd=%i,yspd=%i",fix2int16(ballz[i][0]),fix2int16(ballz[i][1]),fix2int16(ballz[i][2]),fix2int16(ballz[i][3]));
        // tft_writeString(buffer);
        if (ballz[i][0] > int2fix16(314)){ballz[i][0] = int2fix16(314);}
        if (ballz[i][1] < int2fix16(6)){ballz[i][1] = int2fix16(6);}
        if (ballz[i][1] > int2fix16(234)){ballz[i][1] = int2fix16(234);}
        if ((ballz[i][0] > int2fix16(75)) && (ballz[i][0] < int2fix16(85)) && ((ballz[i][1] <= int2fix16(64)) || (ballz[i][1] >=int2fix16(176)))){
          if (ballz[i][2] > int2fix16(0)){ // hit from left
            ballz[i][0]=int2fix16(86);  
          }
          if (ballz[i][2] <= int2fix16(0)){ // hit from right
            ballz[i][0]=int2fix16(74);
          }
        }
        // if ((ballz[i][0] > int2fix16(bumperHorDist+ballRadius) || ballz[i][0] < int2fix16(bumperHorDist-ballRadius)) && 
        //     (ballz[i][1] <= int2fix16(bumperLocation + bumperLength + ballRadius)) && ballz[i][1] >= int2fix16(bumperLocation - ballRadius)){
        //   ballz[i][0]=bumperHorDist+ballRadius+1; 
        // }
        if ((ballz[i][0] > int2fix16(bumperHorDist-ballRadius-3) && ballz[i][0] < int2fix16(bumperHorDist+ballRadius)) && 
            (ballz[i][1] <= int2fix16(bumperLocation + bumperLength + ballRadius)) && ballz[i][1] >= int2fix16(bumperLocation - ballRadius)){
          ballz[i][0]=int2fix16(bumperHorDist+ballRadius+1); 
        }
          if (oldBumperLocation != bumperLocation)
          {

            tft_drawFastVLine(bumperHorDist, oldBumperLocation, bumperLength, ILI9340_BLACK); //bumper
            tft_drawFastVLine(bumperHorDist, bumperLocation, bumperLength, ILI9340_WHITE); //bumper
          }
          oldBumperLocation=bumperLocation;
        // if ((fix2int16(oldBallz[i][0])!=fix2int16(ballz[i][0])) && (fix2int16(oldBallz[i][1])!=fix2int16(ballz[i][1]))){
          if (oldBallz[i][2]){
            tft_drawPixel(fix2int16(oldBallz[i][0]), fix2int16(oldBallz[i][1]), ILI9340_BLACK); //short x, short y, unsigned short color);
            tft_drawPixel(fix2int16(oldBallz[i][0])+1, fix2int16(oldBallz[i][1]), ILI9340_BLACK);
            tft_drawPixel(fix2int16(oldBallz[i][0])-1, fix2int16(oldBallz[i][1]), ILI9340_BLACK);
            tft_drawPixel(fix2int16(oldBallz[i][0]), fix2int16(oldBallz[i][1])+1, ILI9340_BLACK);
            tft_drawPixel(fix2int16(oldBallz[i][0]), fix2int16(oldBallz[i][1])-1, ILI9340_BLACK);  
              // tft_fillCircle(fix2int16(oldBallz[i][0]), fix2int16(oldBallz[i][1]), ballRadius, ILI9340_BLACK); //x, y, radius, color
          }
          if (ballz[i][5]){
            tft_drawPixel(fix2int16(ballz[i][0]), fix2int16(ballz[i][1]), ILI9340_WHITE); //short x, short y, unsigned short color);
            tft_drawPixel(fix2int16(ballz[i][0])+1, fix2int16(ballz[i][1]), ILI9340_WHITE);
            tft_drawPixel(fix2int16(ballz[i][0])-1, fix2int16(ballz[i][1]), ILI9340_WHITE);
            tft_drawPixel(fix2int16(ballz[i][0]), fix2int16(ballz[i][1])+1, ILI9340_WHITE);
            tft_drawPixel(fix2int16(ballz[i][0]), fix2int16(ballz[i][1])-1, ILI9340_WHITE); 
            // tft_fillCircle(fix2int16(ballz[i][0]), fix2int16(ballz[i][1]), ballRadius, ILI9340_WHITE); //x, y, radius, color  
            oldBallz[i][0] = ballz[i][0];
            oldBallz[i][1] = ballz[i][1];
            oldBallz[i][2] = 1;
          } else {
            oldBallz[i][2] =0;
          }
        // }
        ballz[i][6]+= int2fix16(1);
      }
    
      //tft_fillRoundRect(100,2, 250, 10, 1, ILI9340_BLACK);// x,y,w,h,radius,color
      
    }
    PT_YIELD_TIME_msec(67 - (PT_GET_TIME() - begin_time)) ;
    //^ it's supposed to be that for 15 fps
    // PT_YIELD_TIME_msec(67);
  } // end while

  PT_END(pt);
}

static PT_THREAD (protothread_compute_paddle(struct pt *pt)){
  PT_BEGIN(pt);
  while(1){
    begin_time = PT_GET_TIME();
    adc = ReadADC10(0);   // read the result of channel 9 conversion from the idle buffer
    AcquireADC10(); // not needed if ADC_AUTO_SAMPLING_ON below 
    adcVoltage = adc ; // Vref*adc/1023
    bumperLocation = adcVoltage*220/1024;
    PT_YIELD_TIME_msec(67 - (PT_GET_TIME() - begin_time)) ; //15 fps    
    //^ it's supposed to be that for 15 fps
    // PT_YIELD_TIME_msec(67);

  }
  PT_END(pt);
}


static PT_THREAD (protothread_compute_balls(struct pt *pt))
{
  PT_BEGIN(pt);

  while(1) {
    frameRate++;
    if (gameOngoing){
      begin_time = PT_GET_TIME();
    //   For each ball i from 1 to n
      for (i = 0; i < ballCount; ++i){
    //   For each ball j from i+1 to n
        if (ballz[i][5] && ballz[i][4]==0){  
          for (j = i+1; j < ballCount; ++j){
      //   Compute approximate rij by checking:
      //   if ?x and ?y are both less than 4
            if (ballz[j][5] && ballz[j][4]==0 &&(absfix16(ballz[i][0] - ballz[j][0]) < int2fix16(2*ballRadius)) &&
             (absfix16(ballz[i][1] - ballz[j][1]) < int2fix16(2*ballRadius))){
      //    if (||rij||2 less than (2*(ballRadius))2 and hitCounter is zero)
              rijx = ballz[i][0] - ballz[j][0];
              rijy = ballz[i][1] - ballz[j][1];
              mag =multfix16(rijx,rijx)+multfix16(rijy,rijy); 
              if (mag < int2fix16(4*ballRadius*ballRadius) ){
                  vijx = ballz[i][2] - ballz[j][2];
                  vijy = ballz[i][3] - ballz[j][3];
                  dvx = -divfix16(multfix16(rijx,multfix16(rijx,vijx)),mag);
                  dvy = -divfix16(multfix16(rijy,multfix16(rijy,vijy)),mag);
                  //     Compute vij
                  //     Compute ?vi
                  //     Add ?vi to vi
                  ballz[i][2] += dvx;
                  ballz[i][3] += dvy;
                  //     Subtract ?vi from vj
                  ballz[j][2] -= dvx;
                  ballz[j][3] -= dvy;
      //     Set hitCounter big enough to avoid particle capture
                  ballz[i][4]=int2fix16(15); //5 frames must pass
                  //ballz[j][4]=int2fix16(9);
                  // tft_fillRoundRect(80,200, 220, 24, 1, ILI9340_BLACK);// x,y,w,h,radius,color
                  // tft_setCursor(80, 200);
                  // sprintf(buffer,"ball 1=%i:%i,%i, ball 2=%i:%i,%i", i,fix2int16(ballz[i][0]),fix2int16(ballz[i][1]),j,fix2int16(ballz[j][0]),fix2int16(ballz[j][1]));
                  // tft_writeString(buffer);
                  // tft_fillRoundRect(80,210, 220, 24, 1, ILI9340_BLACK);// x,y,w,h,radius,color
                  // tft_setCursor(80, 210);
                  // sprintf(buffer,"dvx=%f,dvy=%f",fix2float16(dvx),fix2float16(dvy));
                  // tft_writeString(buffer);
      //    elseif (hitCounter>0)
      //     decrement hitCounter
            }//    endif
          }//   endif
        }
      }//   endfor
      else if (ballz[i][4]>0){
        ballz[i][4]-=int2fix16(1);
      }
      
    }// endfor
    
    // For each ball i from 1 to n
    for (i = 0; i < ballCount; ++i){
      //   erase ball i||||||| WE WANT TO JUST REDRAW THE NEW PART
      if (ballz[i][5]){
      //   update ball i velocity using drag and wall collisions
        // update positions
        ballz[i][0]+=ballz[i][2];
        ballz[i][1]+=ballz[i][3];

        if (ballz[i][0]<int2fix16(5)){
          ballz[i][5]=0;
          DmaChnEnable(scoreDown);
          score--; currentBallz--;
        }
        if (ballz[i][1]>int2fix16(234)){ //check horizontal walls
          ballz[i][3]= -ballz[i][3];
        }
        if (ballz[i][1]<int2fix16(6)){
          ballz[i][3]= -ballz[i][3];
        }
        // //barriers tho?
        if ((ballz[i][0] > int2fix16(75)) && (ballz[i][0] < int2fix16(85)) && ((ballz[i][1] <= int2fix16(64)) || (ballz[i][1] >=int2fix16(176)))){
          if (ballz[i][2] > int2fix16(0)){ // hit from left
            ballz[i][5]=0;
            DmaChnEnable(scoreUp);
            score++; currentBallz--;
          }
          if (ballz[i][2] <= int2fix16(0)){ // hit from right
            ballz[i][2] = - ballz[i][2];  
          }
        }
        // // if you hit the bumper
        if ((ballz[i][0] > int2fix16(bumperHorDist-ballRadius-3) && ballz[i][0] < int2fix16(bumperHorDist+ballRadius)) && 
            (ballz[i][1] <= int2fix16(bumperLocation + bumperLength + ballRadius)) && ballz[i][1] >= int2fix16(bumperLocation - ballRadius)){
          ballz[i][2] = - ballz[i][2];  
        }

        ballz[i][2] = multfix16(ballz[i][2], float2fix16(drag));
        ballz[i][3] = multfix16(ballz[i][3], float2fix16(drag));
      //   update position
        
        if (ballz[i][0]>int2fix16(314)){ //check vertical wall
          ballz[i][2]= -ballz[i][2];
        }
        //if you went past the wall, you get put on the wall
        
      //   add 1 to age
        
      }
    }// endfor
    
    // Inject new balls into playing field (if any) - at this point in time we know the oldest ball

    
    // Check for user interaction by reading ADC and buttons (if any)
    
    // 15 fps => frame time of 67 mSec
    } else {
      DmaChnEnable(endGame);
      tft_setCursor(100, 100);
      tft_setTextSize(3);
      if (score>0){
        tft_setTextColor(ILI9340_GREEN);
        tft_writeString("u win");
      } else if(score<0){
        tft_setTextColor(ILI9340_RED);
        tft_writeString("u lose");
      } else {
        tft_setTextColor(ILI9340_YELLOW);
        tft_writeString("u tie");
      }
      
    }
    PT_YIELD_TIME_msec(67 - (PT_GET_TIME() - begin_time)) ;
    //^ it's supposed to be that for 15 fps
    // PT_YIELD_TIME_msec(67);
  } // end while

  PT_END(pt);
} // end thread

// === Main  ======================================================
void main(void) {
 //SYSTEMConfigPerformance(PBCLK);

  ANSELA = 0; ANSELB = 0; 

  // === config threads ==========
  // turns OFF UART support and debugger pin, unless defines are set
  PT_setup();

  // === setup system wide interrupts  ========
  INTEnableSystemMultiVectoredInt();

  // init the threads
  PT_INIT(&pt_timer);
  PT_INIT(&pt_color);
  PT_INIT(&pt_anim);

  // init the display
  tft_init_hw();
  tft_begin();
  tft_fillScreen(ILI9340_BLACK);
  //240x320 vertical display
  tft_setRotation(1); // Use tft_setRotation(1) for 320x240

  // seed random color
  srand(1);

  tft_drawRect(0, 0, 320, 240, ILI9340_WHITE);
  tft_drawFastVLine(80, 0, 60, ILI9340_WHITE); //top wall
  tft_drawFastVLine(80, 180, 60, ILI9340_WHITE); //bottom wall
  tft_drawFastVLine(bumperHorDist, bumperLocation, bumperLength, ILI9340_WHITE); //bumper

  OpenTimer2(T2_ON | T2_SOURCE_INT | T2_PS_1_1, 909); //40Mhz/x = 6300 cuz thts the right freq

  DmaChnOpen(scoreUp, 0, DMA_OPEN_DEFAULT);
  DmaChnSetTxfer(scoreUp, bubble, (void*)&SPI2BUF, 3407*2, 2, 2);
  DmaChnSetEventControl(scoreUp, DMA_EV_START_IRQ(_TIMER_2_IRQ));

  DmaChnOpen(scoreDown, 0, DMA_OPEN_DEFAULT);
  DmaChnSetTxfer(scoreDown, punch, (void*)&SPI2BUF, 6009*2, 2, 2);
  DmaChnSetEventControl(scoreDown, DMA_EV_START_IRQ(_TIMER_2_IRQ));

  DmaChnOpen(endGame, 0, DMA_OPEN_AUTO);
  DmaChnSetTxfer(endGame, revMario, (void*)&SPI2BUF, 11294*2, 2, 2); //updated
  DmaChnSetEventControl(endGame, DMA_EV_START_IRQ(_TIMER_2_IRQ));

  SpiChnOpen(SPI_CHANNEL2, 
  SPI_OPEN_ON | SPI_OPEN_MODE16 | SPI_OPEN_MSTEN | SPI_OPEN_CKE_REV | SPICON_FRMEN | SPICON_FRMPOL,
  2);
  PPSOutput(4, RPB10, SS2);
  PPSOutput(2, RPB5, SDO2);

  CloseADC10(); // ensure the ADC is off before setting the configuration
  
  // configure to sample AN11
  SetChanADC10( ADC_CH0_NEG_SAMPLEA_NVREF | ADC_CH0_POS_SAMPLEA_AN11 );
  // configure ADC using the parameters defined above
  OpenADC10( PARAM1 , PARAM2 , PARAM3 , PARAM4 , PARAM5 );
  EnableADC10(); // Enable the ADC
  tft_setTextSize(2);
  tft_setTextColor(ILI9340_WHITE); 

  srand(1);
  // round-robin scheduler for threads
  while (1){
// static struct pt pt_timer, pt_color, pt_anim, pt_sound, pt_insert, pt_paddle,pt_draw ;

    PT_SCHEDULE(protothread_timer(&pt_timer));
    PT_SCHEDULE(protothread_insert(&pt_insert));
    PT_SCHEDULE(protothread_draw(&pt_draw));
    PT_SCHEDULE(protothread_compute_paddle(&pt_paddle));
    PT_SCHEDULE(protothread_compute_balls(&pt_ballz));
  }
} // main

// === end  ======================================================
