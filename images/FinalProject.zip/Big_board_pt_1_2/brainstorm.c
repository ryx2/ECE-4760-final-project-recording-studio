#include "config.h"
// threading library
#include "pt_cornell_1_2.h"

////////////////////////////////////
// graphics libraries
#include "tft_master.h"
#include "tft_gfx.h"
// need for rand function
#include <math.h>
#include <stdlib.h>
#include "bubble.h"
#include "wavLocs.h"
#include "sounds.h"

#define EnablePullDownA(bits) CNPUACLR=bits; CNPDASET=bits;
#define DisablePullDownA(bits) CNPDACLR=bits;
#define EnablePullUpA(bits) CNPDACLR=bits; CNPUASET=bits;
#define DisablePullUpA(bits) CNPUACLR=bits;
#define EnablePullDownB(bits) CNPUBCLR=bits; CNPDBSET=bits;
#define DisablePullDownB(bits) CNPDBCLR=bits;
#define EnablePullUpB(bits) CNPDBCLR=bits; CNPUBSET=bits;
#define DisablePullUpB(bits) CNPUBCLR=bits;
#define DAC_config_chan_A 0b0011000000000000
#define DAC_config_chan_B 0b1011000000000000

#define PIN_0 BIT_0 //RA_0
#define PIN_1 BIT_1 //RA1
#define PIN_2 BIT_0 //RB13
#define PIN_3 BIT_1 //RB14
#define PIN_4 BIT_10 //Rb10
#define PIN_5 BIT_9 // rb9 
#define PIN_6 BIT_8 // rb8
#define PIN_7 BIT_7 // rb7
#define PIN_8 BIT_2 // ra2
#define PIN_9 BIT_3 // ra3
#define rWavSize 24000
#define wavLength 8737

volatile SpiChannel spiChn = SPI_CHANNEL2 ; // the SPI channel to use
volatile int spiClkDiv = 2 ; 

// string buffer
char buffer[60];
char arrow[2]; // arrow for menu selection

char getReady[10];

int arrPos=20, oldArrPos=20;
int recording,playback=0,oldPlayback=0; // 1 if recording, 0 if not
int soundOut=0; //final sound output
int pressed[10]={0}; //if or if not each button is pressed
int oldPressed[10]={0}; //if or if not each button is pressed
int wavLoc[4][8]= {
  {0+1, 72+1,         120+1,         241+1,         350+1,         483+1,         619+1,         731+1},
  {777+1, 921+1,        1034+1,        1185+1,        1375+1,        1521+1,        1678+1,        1800+1},
  {1876+1, 2061+1,       2194+1,       2879+1,       3156+1,       3401+1,       3635+1,             3842+1},
  {4028+1, 4503+1,        5574+1,        5827+1,        6192+1,        7665+1,        7907+1,        8532+1}
};
// {
// {wavStart[0][0],wavStart[0][1], wavStart[0][2], wavStart[0][3], wavStart[0][4],wavStart[0][5], wavStart[0][6], wavStart[0][7]},
// {wavStart[1][0],wavStart[1][1], wavStart[1][2], wavStart[1][3], wavStart[1][4],wavStart[1][5], wavStart[1][6], wavStart[1][7]},
// {wavStart[2][0],wavStart[2][1], wavStart[2][2], wavStart[2][3], wavStart[2][4],wavStart[2][5], wavStart[2][6], wavStart[2][7]},
// {wavStart[3][0],wavStart[3][1], wavStart[3][2], wavStart[3][3], wavStart[3][4],wavStart[3][5], wavStart[3][6], wavStart[3][7]}};
// location of current time within each wave
//int wavStart[4][8]={{0}}; //cumulative start locations of 8 sounds
int bitAddresses[8]={PIN_0, PIN_1, PIN_2, PIN_3, PIN_4, PIN_5, PIN_6, PIN_7};
int i =0;

//variables we need to init: wavLength: length of the wave in the sounds file
//THIS ISNT COMPLETE SOUNDS NEEDS TO BE FIXED
//static const char sounds [wavLength]; //
int mode =0; //mode 0=piano, 1=guitar, 2=bass 3=drums 

//sounds is the 8xwavLength table of sound files

// sound recording wave
int rInd =0;
 
char recordWav[rWavSize] = {0};

static struct pt pt_draw, pt_button ;

void __ISR(_TIMER_2_VECTOR, ipl2) Timer2Handler2(void)
{
    // 74 cycles to get to this point from timer event
    mT2ClearIntFlag();
    soundOut=0;
    for (i = 0; i < 8; ++i){
    	if (pressed[i]){
//        tft_setCursor(40,250);
//        sprintf(buffer, "pressed: %i", i); // when in this mode, record the user
//        tft_writeString(buffer);
    		 soundOut+=sounds[wavStart[mode][i]+wavLoc[mode][i]];
        if(i ==7){
            if(mode !=3){
              wavLoc[mode][i]= wavLoc[mode][i]>=wavStart[mode+1][0] ? wavStart[mode][i] : wavLoc[mode][i]+1;
            } 
            else{
              wavLoc[mode][i]= wavLoc[mode][i]>=wavLength ? wavStart[mode][i] : wavLoc[mode][i]+1;
            }
        }
        else wavLoc[mode][i]= wavLoc[mode][i]>=wavStart[mode][(i+1)] ? wavStart[mode][i] : wavLoc[mode][i]+1;
    	}
      else{ soundOut +=0;}
    }
    if (playback){
      // soundOut+=recordWav[rInd];
    }
    if (recording){
      recordWav[rInd] += soundOut;
      if(rInd >= rWavSize){
          recording = 0;
          rInd=0;
      }
    }
    if (playback || recording){ //increment the playback/record index
      rInd++;
    }
   // soundOut=soundOut<<2>4092?4092:soundOut<<2;//single sound has max at 4092
	mPORTBClearBits(BIT_4); // start transaction
	// test for ready
	//while (TxBufFullSPI2());
	// write to spi2 
	WriteSPI2( DAC_config_chan_A | (soundOut));
	while (SPI2STATbits.SPIBUSY); // wait for end of transaction
	// CS high
	mPORTBSetBits(BIT_4); // end transaction
} // end ISR TIMER2

static PT_THREAD (protothread_button(struct pt *pt)){
  PT_BEGIN(pt);
    while(1){
      oldPressed[0]=mPORTAReadBits(PIN_0);
      oldPressed[1]=mPORTAReadBits(PIN_1);
      oldPressed[2]=mPORTBReadBits(PIN_2);
      oldPressed[3]=mPORTBReadBits(PIN_3);
      oldPressed[4]=mPORTBReadBits(PIN_4);
      oldPressed[5]=mPORTBReadBits(PIN_5);
      oldPressed[6]=mPORTBReadBits(PIN_6);
      oldPressed[7]=mPORTBReadBits(PIN_7);
      oldPressed[8]=mPORTAReadBits(PIN_8);
      oldPressed[9]=mPORTAReadBits(PIN_9);
      PT_YIELD_TIME_msec(30);
      pressed[0]=oldPressed[0]==mPORTAReadBits(PIN_0) ? oldPressed[0] : pressed[0];
      pressed[1]=oldPressed[1]==mPORTAReadBits(PIN_1) ? oldPressed[1] : pressed[1];
      pressed[2]=oldPressed[2]==mPORTBReadBits(PIN_2) ? oldPressed[2] : pressed[2];
      pressed[3]=oldPressed[3]==mPORTBReadBits(PIN_3) ? oldPressed[3] : pressed[3];
      pressed[4]=oldPressed[4]==mPORTBReadBits(PIN_4) ? oldPressed[4] : pressed[4];
      pressed[5]=oldPressed[5]==mPORTBReadBits(PIN_5) ? oldPressed[5] : pressed[5];
      pressed[6]=oldPressed[6]==mPORTBReadBits(PIN_6) ? oldPressed[6] : pressed[6];
      pressed[7]=oldPressed[7]==mPORTBReadBits(PIN_7) ? oldPressed[7] : pressed[7];
      pressed[8]=oldPressed[8]< mPORTAReadBits(PIN_8) ?             1 :          0;
      pressed[9]=oldPressed[9]< mPORTAReadBits(PIN_9) ?             1 :          0;

      if (pressed[8]){
        arrPos+=20;
        if(mode<3)mode++;
        if (arrPos>140){
          arrPos=20;
          mode = 0;
        }

      }      
      if (pressed[9]){
        if (arrPos==120){ //delete recording
          for (i = 0; i < rWavSize; ++i){
            recordWav[i]=0;
          }
        } else if(arrPos==140){ //set playback
            playback=!playback;
            if (playback && recording){
              rInd=0; // reset reconding indexs
            }
        } else {
          recording= recording ==0 ? 1 :0;
          if (recording){
            tft_setCursor(100,300);
            tft_writeString(getReady);
            PT_YIELD_TIME_msec(500);
            oldPlayback=playback;
            playback=0;
            tft_setCursor(100,300);
            tft_setTextColor(ILI9340_BLACK);
            tft_writeString(getReady);
            tft_setTextColor(ILI9340_YELLOW); 
            playback=oldPlayback;
          }
        }
      }
//      PT_YIELD_TIME_msec(50);
    }
  PT_END(pt);
}


static PT_THREAD (protothread_draw(struct pt *pt)){
	PT_BEGIN(pt);
	while(1){
  		tft_setCursor(10,oldArrPos);
  		tft_setTextColor(ILI9340_BLACK);
  		tft_writeString(arrow);
    	tft_setTextColor(ILI9340_YELLOW); 
  		tft_setCursor(10, arrPos);
      oldArrPos = arrPos;
    	tft_writeString(arrow);
    	if (recording){
    		tft_fillCircle(235,300,5,ILI9340_RED);
    	} else {
    		tft_fillCircle(235,300,5,ILI9340_BLACK);
    	}
    	PT_YIELD_TIME_msec(50);
	}
  	PT_END(pt);
}


void main(void) {
 SYSTEMConfigPerformance(PBCLK);

 ANSELA = 0; ANSELB = 0; CM1CON = 0; CM2CON = 0;
  OpenTimer2(T2_ON | T2_SOURCE_INT | T2_PS_1_1, 5000); //40Mhz/5000 aka 8 khz
  // set up the timer interrupt with a priority of 2
  ConfigIntTimer2(T2_INT_ON | T2_INT_PRIOR_2);
  mT2ClearIntFlag(); // and clear the interrupt flag

  /// SPI setup //////////////////////////////////////////
  // SCK2 is pin 26 
  // SDO2 is in PPS output group 2, could be connected to RB5 which is pin 14
  PPSOutput(2, RPB5, SDO2);
  // control CS for DAC
  mPORTBSetPinsDigitalOut(BIT_4);
  mPORTBSetBits(BIT_4);
  // divide Fpb by 2, configure the I/O ports. Not using SS in this example
  // 16 bit transfer CKP=1 CKE=1
  // possibles SPI_OPEN_CKP_HIGH;   SPI_OPEN_SMP_END;  SPI_OPEN_CKE_REV
  // For any given peripherial, you will need to match these
  SpiChnOpen(spiChn, SPI_OPEN_ON | SPI_OPEN_MODE16 | SPI_OPEN_MSTEN | SPI_OPEN_CKE_REV , spiClkDiv);
  // === config threads ==========
  // turns OFF UART support and debugger pin
 PT_setup();

  // === setup system wide interrupts  ========
 INTEnableSystemMultiVectoredInt();

 //Enable Pulldown for Keyboard
 mPORTASetPinsDigitalIn(PIN_0 | PIN_1 | PIN_8 | PIN_9);    //Set port as input
 EnablePullDownA(PIN_0 | PIN_1 | PIN_8 | PIN_9);
 mPORTBSetPinsDigitalIn(PIN_2 | PIN_3 | PIN_4 | PIN_5 | PIN_6 | PIN_7);    //Set port as input
 EnablePullDownB(PIN_2 | PIN_3 | PIN_4 | PIN_5 | PIN_6 | PIN_7);


 sprintf(arrow, " >");
 sprintf(getReady, "Get ready!");

  // init the threads
 // PT_INIT(&pt_timer);
 // PT_INIT(&pt_color);
 PT_INIT(&pt_draw);
 PT_INIT(&pt_button);

  // init the display
 tft_init_hw();
 tft_begin();
 tft_setTextColor(ILI9340_WHITE);  tft_setTextSize(2);
 tft_fillScreen(ILI9340_BLACK);
  //240x320 vertical display
  tft_setRotation(0); // Use tft_setRotation(1) for 320x240

  mPORTBSetPinsDigitalIn(BIT_10);    //Set port as input
  mPORTBSetPinsDigitalIn(BIT_3);    //Set port as input
  // round-robin scheduler for threads

  tft_setCursor(40,20);
  sprintf(buffer,"piano"); // when in this mode, buttons 1-8 play the instrument
  tft_writeString(buffer);
  tft_setCursor(40,40);
  sprintf(buffer,"guitar");// when in this mode, buttons 1-8 play the instrument
  tft_writeString(buffer);
  tft_setCursor(40,60);
  sprintf(buffer,"bass");// when in this mode, buttons 1-8 play the instrument
  tft_writeString(buffer);
  tft_setCursor(40,80);
  sprintf(buffer,"drums");// when in this mode, buttons 1-8 play the instrument
  tft_writeString(buffer);
  tft_setCursor(40,100);
  sprintf(buffer,"user"); // when in this mode, record the user
  tft_writeString(buffer);
  //for all options above, hitting record starts recording the sounds being played, the effect of pressing
  // record changes for the menu options below
  tft_setCursor(40,120);
  sprintf(buffer,"delete");// when in this mode, delete the recorded item if record is pressed
  tft_writeString(buffer);

  tft_setCursor(40,140);
  sprintf(buffer,"playback");// toggles playback if record is pressed
  tft_writeString(buffer);


  while (1){
    PT_SCHEDULE(protothread_draw(&pt_draw));
    PT_SCHEDULE(protothread_button(&pt_button));
  }
  
} // main